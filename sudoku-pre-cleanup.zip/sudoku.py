import inspect
import copy
from itertools import permutations, combinations
from typing import List, Type, Callable
from sudoku_utils import *
import os

class SudokuData:
    rows: list
    cols: list
    blocks: list
    ref: dict

    def __init__(self, slots: list=None):
        self.rows = list([0 for x in range(ROWS)] for y in range(ROWS))
        self.cols = list([0 for x in range(ROWS)] for y in range(ROWS))
        self.blocks = list([0 for x in range(ROWS)] for y in range(ROWS))
        if not slots:
            print("Empty SudokuData")
            return
        for x in range(ROWS):
            for y in range(ROWS):
                a, b = ref[(x, y)][2]
                self.rows[x][y] = self.cols[y][x] = self.blocks[a][b] = slots[x][y]
        self.ref = {"rows": self.rows, "cols": self.cols, "blocks": self.blocks}

    def add_entry(self, entry):
        z, x, y = entry
        if self.rows[x][y] and self.rows[x][y] != z:
            print("Error: Collision. Previously played entry found:", self.rows[x][y], "vs", z, "@", x,y)
            assert False
        elif self.rows[x][y] == z:
            print("Duplicate Entry @", x, y, z, "xyz", self.rows[x][y], "vs", z)
            return True
        bx, by = ref[(x, y)][2]
        if z in self.rows[x] or z in self.cols[y] or z in self.blocks[bx]:
            print("Error: Collision. With rows/cols/block mismatch")
            assert False
        self.cols[y][x] = self.rows[x][y] = z
        _p, _q = ref[(x, y)][2]
        self.blocks[_p][_q] = z
        return True

    def draw(self): print_sudoku(self.rows)

    def get_progress(self):
        return sum(x > 0 for index in range(ROWS) for x in self.rows[index])

    def get_plays(self, x, y):
        b_idx = ref[(x, y)][2][0]  # b_idx = block index
        return list(play_set - set(self.rows[x] + self.cols[y] + self.blocks[b_idx]))

    def open_slots(self):
        slots = []
        for _i in range(ROWS):
            for _j in range(ROWS):
                if self.rows[_i][_j] == 0:
                    slots.append((_i, _j))
        return slots

    def validate(self): return has_no_dupes([*self.rows, *self.cols, *self.blocks])

    def check_entry(self, z, x, y):
        block_index = ref[(x, y)][2][0]
        return self.rows[x][y] == 0 and 0 < z <= ROWS and \
               z not in self.rows[x] and z not in self.cols[y] and z not in self.blocks[block_index]

    def check_solved(self):
        r, c, b = self.rows, self.cols, self.blocks
        return all(play_set == set(r[_i]) == set(c[_i]) == set(b[_i]) for _i in range(ROWS))


# noinspection PyMethodMayBeStatic
class Group:
    source: str
    idx: int
    array: [list]

    count: int
    index: int
    slots: [int]
    xy: list
    mirrors: list
    m_groups: list
    m_slots: list
    reduced: list
    permutes: list
    g_slots: list
    g_plays: list

    def __init__(self, array: list, idx):
        self.array = array
        self.source = table[idx // ROWS]
        self.idx = idx
        self.slots = array[idx]
        self.xy, self.mirrors, self.m_groups = [], [], []
        self.g_slots, self.g_plays = [], []
        self.permutes = []
        for _k in range(ROWS):
            fields = REFP[(idx, _k)]
            self.xy += [fields[XY]]
            self.mirrors += [fields[OT]]
            self.m_groups += [fields[OX]]

            # print("# i-k-xy-ot-ox-slots-oslots",self.idx, _k, fields[XY], fields[OT], fields[OX])

    def group_info(self):
        print("Group: ", self.source, self.idx, "#", self.slots, "count/slots:", self.free_count(), self.free_slots())

    def info(self, iy):
        print("Info: (i.y.xy)", self.idx, iy, self.xy[iy], "mirrors, m-groups:", self.mirrors[iy], self.m_groups[iy])

        other_sets = []
        other_frees = []
        debug_set = []
        # for slot in self.good_slots:
        #     # more unpacking, get the other lists (row,col,block) of the play's - save in list of sets
        #     q1, q2 = ref[(source, my_idx, slot)][3]  # others
        #     q1_idx, q2_idx = table2[q1[0]] * ROWS + q1[1],  table2[q2[0]] * ROWS + q2[1]
        #     occupied_others = set(self.channels[q1_idx] + self.channels[q2_idx]) - {0}
        #     other_frees.append(play_set - occupied_others)
        #     debug_set.append(((q1,q1_idx),(source,my_idx,slot),(q2,q2_idx)))

    def combined(self, i):
        return self.slots + self.array[REFP[(self. idx, i)][OX][0]] + self.array[REFP[(self.idx, i)][OX][1]]

    def plays(self): return set(self.slots) - {0}

    def playable(self): return play_set - self.plays()

    def free_count(self): return len(self.playable())

    def free_slots(self): return [_iy for _iy in range(ROWS) if self.slots[_iy] == 0]

    def get_free_slot(self, num):
        if num >= self.free_count():
            return []
        return REFP[(self.idx,[_iy for _iy in range(ROWS) if self.slots[_iy] == 0][num])][XY]

    def validate(self):
        return len(self.plays() | self.playable()) == 9 and \
               ROWS - len(self.plays()) == self.free_count() and self.array[self.index] == self.slots

    def translate(self, ix, z: int=None):
        return REFP(self.idx, ix) if not z else (z, *REFP(self.idx, ix))

    def gen_plays(self):   # returns the lowest number of variations of play (set)
        slots = self.g_slots = self.free_slots()
        if not self.g_slots:
            return []
        plays = self.g_plays = [list(play_set - set(self.combined(_k))) for _k in self.g_slots]
        self.reduced = sorted(((plays[_i], REFP[(self.idx,_s)][XY]) for _i, _s in enumerate(slots)), key=lambda _p: len(_p[0]))
        return len(self.reduced[0][0])

    def slots4play(self, _play):
        if _play not in self.playable():
            return []
        self.gen_plays()
        return [REFP[(self.idx, *self.g_slots[_i])][XY] for _i in range(self.free_count()) if _play in self.g_plays[_i]]


    def find_freq(self):
        self.gen_plays()
        pot = [play for g in self.g_plays for play in g]
        plays = list(self.playable())
        frequencies, tb = [], [0]*len(plays)
        for _p in pot:
            tb[plays.index(_p)] += 1
        return sorted(zip(plays, tb))

    def find_permute(self):
        free_slots = self.free_slots()
        free_plays = self.playable()
        count = len(free_plays)

        play_pack = []
        for _k in free_slots:
            free_play = play_set - set(self.combined(_k))
            play_pack.append(free_play)

        self.permutes = []
        permute_ok = []
        for permuted in permutations(free_plays, count):
            walk = 0
            while walk < count:
                if not permuted[walk] in play_pack[walk]:
                    break
                walk += 1
            if walk == count:
                permute_ok.append(permuted)
        self.permutes = [[(_play, *REFP[(self.idx, free_slots[_i])][XY]) for _i, _play in enumerate(p_set)] for p_set in permute_ok]

        if len(self.permutes) == 1:
            return True
        return False

    def find_partial(self, reload: bool = True):
        if reload and self.find_permute():
            return self.permutes[0]
        elif len(self.permutes) < self.free_count():
            return []

        count = self.free_count()
        matched, matched_pack = [], []
        if len(self.permutes) < count:
            for _i in reversed(range(count)):
                if all(self.permutes[0][_i][0] == perm[_i][0] for perm in self.permutes[1:]):
                    matched.append(_i)
                    for repair in self.permutes:
                        repair.pop(_i)
            if matched:
                return [(self.permutes[0][_i][0], *self.permutes[0][_i][1:]) for _i in matched]
        return []

class Trial(SudokuData):
    original: SudokuData
    current: SudokuData
    array: list
    groups: [Group]
    play_records: list
    log: list
    rows: list
    cols: list
    blocks: list
    permuted: list

    # noinspection PyMissingConstructor
    def __init__(self, game: SudokuData):
        self.stop = ROWS*3
        self.original = copy.deepcopy(game)
        self.current = copy.deepcopy(game)
        self.rows, self.cols, self.blocks = self.current.rows, self.current.cols, self.current.blocks
        self.ref = self.current.ref
        self.array = [*self.rows, *self.cols, *self.blocks]
        self.groups = [Group(self.array, _i) for _i in range(ROWS * 3)]

        self.log = []
        self.play_records = []
        self.queue = []
        self.trials = []

    def add_entry(self, entry):
        self.current.add_entry(entry)
        self.play_records.append((entry, inspect.stack()[1][3]))

    def check_trial(self):
        if not self.original.validate():
            print("\nERROR: Original Sudoku is invalid.\n")
            return False
        if not self.validate():
            print("\nERROR: Trial Sudoku is invalid.\n")
            return False
        org, test = self.original.rows, self.rows
        if not all(org[x][y] == 0 or org[x][y] == test[x][y] for x in range(ROWS) for y in range(ROWS)):
            print("\nERROR: Invalid Sudoku: Violating original start.\n")
            return False
        return True

    def auto_solve(self, trial=0):
        channel_check = "update"
        print("trial auto_solve begins")
        if self.check_solved():
            print("* ** Solved! ** *")
            self.draw()
            return SIZE
        last_status = 0
        while last_status != self.get_progress():
            last_status = self.get_progress()
            if self.get_progress() == SIZE:
                print("* ** Solved! ** *")
                self.draw()
                assert self.check_solved() and self.check_trial()
                print("Final check:", self.check_trial())
                return SIZE
            self.try_sets()
            self.try_permutes()
            print("Current Progress:", self.get_progress(), self.get_progress() * 1000 // SIZE / 10, "%")
            self.draw()
        print("Quitting trial auto_solve: final check:", self.check_trial())
        if not self.check_solved():
            self.try_frequencies()
            self.try_each()
            print("Final Progress:", self.get_progress(), self.get_progress() * 1000 // SIZE / 10, "%")

        return self.get_progress()

    def try_frequencies(self):
        print("Freq:", freq(self.rows))
        frequencies = [(fr[0], ROWS - fr[1]) for fr in freq(self.rows) if fr[0] != 0]
        print(frequencies)
        frq = copy.deepcopy(frequencies)
        while frq:
            filtered = list(filter(lambda _k: self.check_entry(frq[0][0], *_k), self.open_slots()))
            if not filtered:
                print("Error: unplayable. Possible Invalid sudoku.")
            if filtered and len(filtered) == frq[0][1] and len(filtered) < 3:
                print_sudoku(self.rows)
                print("Playing:", frq[0][0], "at", filtered)
                while filtered:
                    self.add_entry((frq[0][0], *filtered[0]))
                    filtered.pop(0)
                print_sudoku(self.rows)
            elif filtered:
                print(f"Warning: Play:{frq[0][0]} @freq:{frq[0][1]}x with {len(filtered)} slots.")
                if len(filtered) < frq[0][1]:
                    print("Less slots than frequency. Possible Invalid Sudoku.")
            frq.pop(0)

        return self.get_progress()

    def try_permutes(self):
        # Approach #1 - explore trials for each block (row/col)
        # list, set, set
        print("Current Progress:", self.get_progress())

        groups = sorted(self.groups, key=lambda x: x.free_count())
        groups = [grp for grp in groups if 0 != grp.free_count() != 2]

        total = len(groups)
        factor = total//20 + total//14
        p_groups = groups[: total // (1 + factor)]
        walk = 0
        while True:
            while walk < len(p_groups):
                free_count = p_groups[walk].free_count()
                previous = len(p_groups)
                if free_count == 0:
                    p_groups.pop(walk)
                elif free_count == 1:
                    (play,), (x, y) = p_groups[walk].playable(), p_groups[walk].get_free_slot(0)
                    self.add_entry((play, x, y))
                    p_groups.pop(walk)
                elif free_count == 2:
                    while p_groups[walk].gen_plays() == 1:
                        [(play,), (x, y)] = p_groups[walk].reduced[0]
                        self.add_entry((play, x, y))
                    if p_groups[walk].free_count() == 2:
                        p_groups.pop(walk)
                else:
                    if p_groups[walk].find_permute():
                        for entry in p_groups[walk].permutes[0]:
                            self.add_entry(entry)
                        p_groups.pop(walk)
                    else:
                        entries = p_groups[walk].find_partial()
                        if entries:
                            for entry in p_groups[walk].permutes[0]:
                                self.add_entry(entry)
                            break
                if previous != len(p_groups):
                    break
                walk += 1
            if walk >= len(p_groups) and factor:
                half = total // (1 + factor)
                p_groups = groups[half:]
                factor = 0
                walk = 0
            elif walk >= len(p_groups):
                break
        return self.get_progress()

    def try_sets(self):  # Fill those with empty-count: 1 (or) 2 if possible (after confirmation)
        stop, full_slots = ROWS*3, set()
        while True:
            idx = 0
            pair_sets = set()
            while idx < stop:
                group = self.groups[idx]
                # print("iterate over idx ", idx, group.free_count(),group.slots)
                if idx in full_slots or idx in pair_sets:
                    idx += 1
                    continue
                free_count = group.free_count()
                if free_count == 0:
                    full_slots.add(idx)
                elif free_count == 1:
                    (play,), (x, y) = group.playable(), group.get_free_slot(0)
                    self.add_entry((play, x, y))
                elif free_count < 4:
                    while group.gen_plays() == 1:   # returns the lowest number of variations of play (set)
                        [(play,), (x, y)] = group.reduced[0]
                        self.add_entry((play, x, y))
                        group.reduced.pop(0)
                    if group.free_count() == 2:
                        pair_sets.add(idx)
                if free_count != group.free_count():
                    break
                idx += 1
            if idx >= stop:
                return self.get_progress()

    def try_each(self):
        groups = self.groups[0:ROWS]
        walk = 0
        while True:
            state = len(groups)
            while walk < len(groups):
                if groups[walk].free_count() == 0:
                    groups.pop(walk)
                    continue
                while groups[walk].gen_plays() == 1:
                    [(play,), (x, y)] = groups[walk].reduced[0]
                    self.add_entry((play, x, y))
                if groups[walk].free_count() == 2:
                    pair_groups = groups.pop(walk)
                    continue
                else:
                    remove_dupes(list(map(set, groups[walk].g_plays)))
                walk += 1
            if walk >= len(groups) and state == len(groups):
                break

class Game(SudokuData):
    sudoku: SudokuData
    trials: [Trial]
    log: list

    # noinspection PyMissingConstructor
    def __init__(self, file_name: str =None):
        if not file_name:
            _slots = self.load_file("games\\s01a.txt")
            self.sudoku = SudokuData(_slots)
        else:
            _slots = self.load_file(file_name)
            self.sudoku = SudokuData(_slots)
        self.rows, self.cols, self.blocks = self.sudoku.rows, self.sudoku.cols, self.sudoku.blocks
        self.ref = self.sudoku.ref
        self.trials = []

    def add_entry(self, entry):
        self.sudoku.add_entry(entry)

    @staticmethod
    def load_file(file_name):
        list_of_lists = []
        print(file_name)
        with open(file_name) as f:
            for _i, line in enumerate(f):
                if _i == ROWS:
                    break
                line = line[:-2]
                inner_list = [int(elt.strip()) for elt in line.split(' ')]
                # in alternative, if you need to use the file content as numbers
                # inner_list = [int(elt.strip()) for elt in line.split(',')]
                list_of_lists.append(inner_list)

        return list_of_lists[0:ROWS]

    def print(self):
        print_sudoku(self.sudoku.rows)

    def add_trial(self, slots=None, starter_list=None):
        # Can base on the original(s=None) or orig-variant or entirely-new
        if not slots:
            self.trials.append(Trial(self.sudoku))
            return
        self.trials.append(Trial(slots))

    def auto_solve(self, game_id=0):
        self.add_trial()
        print("game autosolve")
        return self.trials[game_id].auto_solve()


def remove_dupes(list_sets):

    count = len(list_sets)
    def subset(_self_i, my_set):
        if not my_set[_self_i]:
            return []
        print(my_set)
        return [my_set[_idx] for _idx in range(count) if _idx != _self_i and my_set[_self_i] <= my_set[_idx]]

    l_set = copy.deepcopy(list_sets)
    playable = []
    frequencies = freq(l_set, reverse=False)
    print("frequencies, set", frequencies, l_set)

    while frequencies:
        play, times = frequencies[0]
        if times == 1:
            p_index = 0
            for _j in range(len(l_set)):
                if subset(_j, l_set):
                    p_index = _j
            playable.append((frequencies[0][0], p_index))
            l_set = list(map(lambda set_plays: set_plays - {play}, l_set))
            print("after map", l_set)
        else:
            break
        frequencies.pop(0)
    indices = list(range(count))
    index_list = []
    for _i in indices:
        i_pool = indices[0:_i]+indices[_i+1:]
        index_list.append([[_c for _c in combinations(i_pool, r=_j)]for _j in range(1,count)])
    printList(index_list,"remove_dupes: indices")
    # packing





    print("Playable so far:", playable)


def load_file(file_string):
    list_of_lists = []
    with open(file_string) as f:
        for line in f:
            #
            # inner_list = [int(elt.strip()) for elt in line.split(' ')]
            list_of_lists.append(line[:-1])
    return list_of_lists


wins, stalled = 0, 0
games_progresses = []

my_game = Game()
my_game.auto_solve()
for k in range(6, 7):
    file_list = load_file("game_list.txt")
    my_game = Game(file_list[k])
    reply = my_game.auto_solve()
    if reply == SIZE:
        wins += 1
    else:
        print("game replied:", reply)
        stalled += 1
        games_progresses.append(reply)
    print("Game Solved:", wins, "against stalled:", stalled)
print(games_progresses)